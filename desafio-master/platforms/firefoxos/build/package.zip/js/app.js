var db = null;

var desafio  = angular.module('desafioApp', ['ionic', 'ngCordova'])

.run(function($ionicPlatform, $cordovaSQLite) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }

    //inicia o banco sql
    db = $cordovaSQLite.openDB({ name: "desafio.db"});

  //  $cordovaSQLite.execute(db,"DROP TABLE IF EXISTS desafio");
    //Cria a tabela  caso não estiver criada
    $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS desafio (id integer primary key, texto text, data text)");
    console.log("TABELA CRIADA");
  });
});

desafio.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('cadastro', {
            url: '/cadastro',
            templateUrl: 'templates/cadastro.html',
            controller: 'cadastroController'
        })
        .state('sobre', {
            url: '/sobre',
            templateUrl: 'templates/sobre.html',
            controller: 'sobreController'
        })
    $urlRouterProvider.otherwise('/cadastro');
});

//Controla o banco
desafio.controller("cadastroController", function($scope, $cordovaSQLite,$ionicPlatform, $ionicLoading, $location){
    $scope.items = []; //Array com os registros
    $scope.texto = ''; //Variavel recebido do input
    $scope.datas = ''; //Variavel recebido do input
    //$scope.dados = {};


    $ionicPlatform.ready(function() {
      $scope.items = [""]; //Limpa o array
    var select = "SELECT id, texto , data FROM desafio";
    //executa o select e imprime no log caso encontrou alguma linha ou se aconteceu algum erro
    $cordovaSQLite.execute(db, select,[]).then(function(result){
      if (result.rows.length > 0 ){
        console.log("SELECIONADO ->" + result.rows.item(0).texto + " " + result.rows.item(0).data);
        //Mostra os resultados
        for (var i = 0; i < result.rows.length ; i++) {
            console.log("SELECIONADO ->" + result.rows.item(i).texto + " " + result.rows.item(i).data +"inicio id: "+i);
            $scope.items.push(result.rows.item(i));
        }
       // alert(JSON.stringify($scope.items));
        console.log("SELECIONADO ->" + result.rows.item(i).texto + " " + result.rows.item(i).data +"Fim id: "+i);
        return $scope.items;
      }else{
        console.log("NENHUMA LINHA ENCONTRADA.");
      }
    }, function(error){
        console.log(error);
    });
  });

  //Função Busca todos registros
  $scope.registros = function(){
    $scope.items = [""]; //Limpa o array
    var select = "SELECT id, texto , data FROM desafio";
    //executa o select e imprime no log caso encontrou alguma linha ou se aconteceu algum erro
    $cordovaSQLite.execute(db, select,[]).then(function(result){
      if (result.rows.length > 0 ){
        console.log("SELECIONADO ->" + result.rows.item(0).texto + " " + result.rows.item(0).data);
        //Mostra os resultados
        for (var i = 0; i < result.rows.length ; i++) {
            $scope.items.push(result.rows.item(i));
        }
        return $scope.items;
      }else{
        console.log("NENHUMA LINHA ENCONTRADA.");
      }
    }, function(error){
        console.log(error);
    });
  }

  //Função inserir  = inclui registro no banco
  $scope.inserir = function(texto,datas){
    $scope.texto = texto;
    $scope.datas = datas;

    console.log($scope.texto)
    console.log($scope.datas)
    var insert = "INSERT INTO desafio ( texto, data) VALUES (?,?)";
    //executa o insert e imprime no log quando inserir ou se aconteceu algum erro.
    $cordovaSQLite.execute(db, insert, [$scope.texto, $scope.datas]).then(function(result){
      console.log("INSERIDO id ->" + result.insertId);
      $scope.items.push({id: result.insertId, texto: $scope.texto, data: $scope.datas});
      $ionicLoading.show({ template: 'Item Adicionado!', noBackdrop: true, duration: 2000 });
      $scope.texto = "";
      $scope.datas = "";
    }, function(error){
      console.log(error);
    });
  }

  $scope.sobre = function(){
    $location.path("/sobre");
  }

});


desafio.controller("sobreController", function($scope, $cordovaSQLite, $location){
  $scope.volta = function(){
      $location.path("/cadastro");
  }
});